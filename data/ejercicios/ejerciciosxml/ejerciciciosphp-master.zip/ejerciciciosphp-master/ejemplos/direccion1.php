<?php

header('Location: direccion2.php');
echo "direccion 1";