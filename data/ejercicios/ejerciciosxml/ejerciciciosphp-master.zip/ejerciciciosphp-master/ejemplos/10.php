<!DOCTYPE html>
<html><head>
        <meta charset="UTF-8">
        <title>ejemplo</title>
</head><body>
    <h2>Nuestro primer formulario</h2>
    <form method="get" action="10action.php">
        <label>Nombre</label><input type="text" value="" name="nombre"><br>
        <label>Apellidos</label><input type="text" value="" name="apellidos"><br>
        <input type="submit" value="enviar">
    </form>
</body></html>