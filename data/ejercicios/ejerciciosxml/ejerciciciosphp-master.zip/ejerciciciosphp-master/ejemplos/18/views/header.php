<header>
  <ul>
    <li><a href="/ejemplos/18?method=index">Inicio</a></li>
    <li><a href="/ejemplos/18?method=login">Login</a></li>
  </ul>
</header>
