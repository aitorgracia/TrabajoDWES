# Ejercicios PHP

- Repositorio con ejercicios sencillos de PHP
- Se adjuntan ejemplos explicativos y después de cada uno se plantean ejercicios para realizar por el alumno.